import investigacaoSvg from "../assets/illustrations/investigacao.svg";
export default function FAQ() {
  return (
    <div>
      <img src={investigacaoSvg} height={60} alt="FAQ" style={{marginBottom:20}} />
      <h2>Perguntas Frequentes</h2>
      {/* ...restante */}
    </div>
  );
}