import { motion } from "framer-motion";
import "./Navbar.css"; // para estilos customizados

export default function Navbar() {
  // ...restante do código
  return (
    <motion.nav className="navbar" /* animação já aplicada */>
      {/* links */}
    </motion.nav>
  );
}