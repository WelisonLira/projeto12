# Front-end do Sistema de Consultas

## Scripts

- `npm install` — instala dependências
- `npm start` — roda o app em modo desenvolvimento

## Configuração

- Copie `.env.example` para `.env` e ajuste a variável `REACT_APP_API_URL` para apontar para seu back-end.

## Observações

- O projeto está pronto para integração com APIs de pagamento, consulta, notificações, etc.
- Basta editar/expandir os componentes conforme suas necessidades.