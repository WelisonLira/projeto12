// ...rotas de login/cadastro
router.post('/forgot-password', async (req, res) => {
  // Envia e-mail com link/token para redefinição de senha
});
router.post('/reset-password', async (req, res) => {
  // Redefine a senha após validação do token
});