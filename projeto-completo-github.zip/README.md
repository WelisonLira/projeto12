# Consultas Online — Projeto React

Portal moderno para investigações digitais com foco em performance, acessibilidade e escalabilidade.

## Recursos:
- React com Lazy Loading
- Estrutura modular com Context API, Hooks e Serviços
- Acessibilidade e testes automatizados
- Pronto para deploy no Vercel

## Rodar o projeto
```bash
npm install
npm start
```

## Rodar testes
```bash
npm test
```
