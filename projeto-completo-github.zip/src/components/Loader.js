import React from "react";

const Loader = () => {
  return (
    <div role="status" aria-live="polite" style={{ textAlign: "center", padding: "2rem" }}>
      <p>Carregando...</p>
    </div>
  );
};

export default Loader;
