import React from "react";
import "./InvestigacaoHero.css";

const InvestigacaoHero = React.memo(({ title, subtitle }) => {
  return (
    <section className="hero" role="region" aria-label="Seção de destaque">
      <h1 tabIndex="0">{title}</h1>
      <p tabIndex="0">{subtitle}</p>
    </section>
  );
});

export default InvestigacaoHero;
