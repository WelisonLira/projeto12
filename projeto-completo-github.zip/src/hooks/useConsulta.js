import { useState, useCallback } from "react";
import axios from "axios";

export function useConsulta(endpoint) {
  const [dados, setDados] = useState(null);
  const [erro, setErro] = useState(null);
  const [carregando, setCarregando] = useState(false);

  const consultar = useCallback(async (parametro) => {
    setCarregando(true);
    setErro(null);
    try {
      const resposta = await axios.get(\`\${endpoint}/\${parametro}\`);
      setDados(resposta.data);
    } catch (error) {
      setErro(error);
    } finally {
      setCarregando(false);
    }
  }, [endpoint]);

  return { dados, erro, carregando, consultar };
}
