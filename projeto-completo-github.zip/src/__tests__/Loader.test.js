import { render, screen } from "@testing-library/react";
import Loader from "../components/Loader";

test("renderiza mensagem de carregamento", () => {
  render(<Loader />);
  expect(screen.getByText("Carregando...")).toBeInTheDocument();
});
