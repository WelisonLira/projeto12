import { render, screen } from '@testing-library/react';
import InvestigacaoHero from '../components/InvestigacaoHero';

test('renderiza título e subtítulo', () => {
  render(<InvestigacaoHero title="Título" subtitle="Subtítulo" />);
  expect(screen.getByText("Título")).toBeInTheDocument();
  expect(screen.getByText("Subtítulo")).toBeInTheDocument();
});
