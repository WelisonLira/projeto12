import React from "react";
import InvestigacaoHero from "../components/InvestigacaoHero";

function Home() {
  return (
    <div>
      <InvestigacaoHero
        title="Consultas Online"
        subtitle="Seu portal para investigações digitais!"
      />
      <h2>Bem-vindo ao sistema de Consultas Online!</h2>
      <p>Consulte informações de maneira rápida e segura.</p>
    </div>
  );
}

export default Home;
